<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of personalize_class
 *
 * @author Emmanuel Eronu
 */
class personalize_class 
{
    public $personalize_table_name = "wpvy_hm_verification";
}
